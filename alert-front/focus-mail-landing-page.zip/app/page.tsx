"use client"

import { motion, useScroll, useTransform, useInView } from "framer-motion"
import { Mail, Zap, Shield, Brain, Sparkles, Filter, ArrowRight } from "lucide-react"
import { useRef, useState } from "react"

export default function FocusMailLanding() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  })

  // Hero zoom and fade effects
  const heroScale = useTransform(scrollYProgress, [0, 0.5], [1, 2])
  const heroOpacity = useTransform(scrollYProgress, [0, 0.3], [1, 0])
  const mockupOpacity = useTransform(scrollYProgress, [0.2, 0.5], [0, 1])
  const mockupY = useTransform(scrollYProgress, [0, 0.5], [100, -50])

  return (
    <div ref={containerRef} className="relative bg-[#fafaf9] text-[#1a1a1a] overflow-x-hidden">
      {/* Hero Section */}
      <section className="relative h-[200vh]">
        <div className="sticky top-0 h-screen flex items-center justify-center overflow-hidden">
          {/* Main headline with zoom effect */}
          <motion.div style={{ scale: heroScale, opacity: heroOpacity }} className="absolute z-20 text-center px-4">
            <h1 className="text-[clamp(3rem,12vw,9rem)] font-bold leading-[0.9] tracking-tight text-balance">
              Your Inbox.
              <br />
              <span className="text-[#71717a]">Silence.</span>
              <br />
              Focus.
            </h1>
            <p className="mt-8 text-xl md:text-2xl text-[#52525b] max-w-2xl mx-auto text-pretty">
              FocusMail scrapes your emails and delivers only what matters.
            </p>
          </motion.div>

          {/* App mockup with parallax */}
          <motion.div style={{ opacity: mockupOpacity, y: mockupY }} className="absolute z-10">
            <div className="relative w-[90vw] max-w-5xl h-[600px] rounded-3xl bg-gradient-to-br from-white to-[#f4f4f5] shadow-2xl border border-[#e4e4e7] overflow-hidden backdrop-blur-xl">
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#fafaf9]/50" />
              <div className="p-8">
                <div className="flex items-center gap-2 mb-6">
                  <div className="w-3 h-3 rounded-full bg-[#ef4444]" />
                  <div className="w-3 h-3 rounded-full bg-[#f59e0b]" />
                  <div className="w-3 h-3 rounded-full bg-[#10b981]" />
                </div>
                <div className="space-y-4">
                  <div className="h-12 bg-white rounded-xl shadow-sm border border-[#e4e4e7] flex items-center px-4 gap-3">
                    <Sparkles className="w-5 h-5 text-[#a855f7]" />
                    <span className="text-[#71717a]">3 critical updates today</span>
                  </div>
                  <div className="h-32 bg-white rounded-xl shadow-sm border border-[#e4e4e7] p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#a855f7]" />
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-[#f4f4f5] rounded w-3/4" />
                        <div className="h-3 bg-[#f4f4f5] rounded w-1/2" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Chaos to Order Section */}
      <ChaosToOrderSection />

      {/* Features Bento Grid */}
      <FeaturesBento />

      {/* How It Works */}
      <HowItWorksSection />

      {/* CTA Footer */}
      <CTASection />
    </div>
  )
}

function ChaosToOrderSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  })

  const leftX = useTransform(scrollYProgress, [0.2, 0.6], [-200, 0])
  const rightX = useTransform(scrollYProgress, [0.2, 0.6], [200, 0])
  const centerScale = useTransform(scrollYProgress, [0.3, 0.7], [0.5, 1])
  const centerOpacity = useTransform(scrollYProgress, [0.3, 0.7], [0, 1])

  return (
    <section ref={sectionRef} className="relative py-40 px-4 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-[clamp(2.5rem,8vw,6rem)] font-bold text-center mb-32 leading-tight"
        >
          From Chaos
          <br />
          <span className="text-[#71717a]">to Order</span>
        </motion.h2>

        <div className="relative h-[400px] flex items-center justify-center">
          {/* Spam emails from left */}
          <motion.div style={{ x: leftX }} className="absolute left-0 space-y-4">
            {["Newsletter", "Promo", "Update", "Spam"].map((label, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.1 }}
                className="px-6 py-3 bg-[#fca5a5] text-white rounded-xl shadow-lg backdrop-blur-sm"
              >
                {label}
              </motion.div>
            ))}
          </motion.div>

          {/* Spam emails from right */}
          <motion.div style={{ x: rightX }} className="absolute right-0 space-y-4">
            {["Ad", "Junk", "Noise", "Clutter"].map((label, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.1 }}
                className="px-6 py-3 bg-[#fca5a5] text-white rounded-xl shadow-lg backdrop-blur-sm"
              >
                {label}
              </motion.div>
            ))}
          </motion.div>

          {/* Center funnel result */}
          <motion.div
            style={{ scale: centerScale, opacity: centerOpacity }}
            className="relative z-10 px-12 py-8 bg-gradient-to-br from-[#8b5cf6] to-[#a855f7] text-white rounded-2xl shadow-2xl"
          >
            <Filter className="w-12 h-12 mx-auto mb-4" />
            <p className="text-2xl font-semibold text-center">3 Critical Updates</p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

function FeaturesBento() {
  const features = [
    {
      icon: <Brain className="w-8 h-8" />,
      title: "AI-Powered Filtering",
      description: "Smart algorithms learn what matters to you",
      gradient: "from-[#8b5cf6] to-[#a855f7]",
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Instant Summaries",
      description: "Get the gist in seconds, not minutes",
      gradient: "from-[#f59e0b] to-[#f97316]",
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Privacy First",
      description: "Your data never leaves your control",
      gradient: "from-[#10b981] to-[#14b8a6]",
    },
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: "Smart Notifications",
      description: "Only get pinged for what's urgent",
      gradient: "from-[#ec4899] to-[#f43f5e]",
    },
  ]

  return (
    <section className="py-32 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-[clamp(2.5rem,8vw,5rem)] font-bold text-center mb-20 leading-tight"
        >
          Built for Focus
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((feature, index) => (
            <FeatureCard key={index} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}

function FeatureCard({ feature, index }: { feature: any; index: number }) {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 60 }}
      transition={{ duration: 0.7, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative group"
    >
      <motion.div
        animate={{
          scale: isHovered ? 1.02 : 1,
        }}
        transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
        className="relative p-8 md:p-12 bg-white rounded-3xl border border-[#e4e4e7] overflow-hidden h-full"
      >
        {/* Glow effect on hover */}
        <motion.div
          animate={{
            opacity: isHovered ? 0.1 : 0,
          }}
          className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} blur-2xl`}
        />

        <div className="relative z-10">
          <div className={`inline-flex p-4 rounded-2xl bg-gradient-to-br ${feature.gradient} text-white mb-6`}>
            {feature.icon}
          </div>
          <h3 className="text-3xl font-semibold mb-4">{feature.title}</h3>
          <p className="text-lg text-[#71717a]">{feature.description}</p>
        </div>
      </motion.div>
    </motion.div>
  )
}

function HowItWorksSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  })

  const scanProgress = useTransform(scrollYProgress, [0.3, 0.7], [0, 100])

  return (
    <section ref={sectionRef} className="py-40 px-4 bg-gradient-to-b from-[#fafaf9] to-white">
      <div className="max-w-5xl mx-auto text-center">
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-[clamp(2.5rem,8vw,5rem)] font-bold mb-12 leading-tight"
        >
          Smart Scraping
          <br />
          <span className="text-[#71717a]">Technology</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="text-xl md:text-2xl text-[#52525b] mb-20 text-pretty"
        >
          Advanced AI analyzes every email, extracting what's important and filtering the rest
        </motion.p>

        <div className="relative w-full h-[400px] flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            {/* Email icon */}
            <div className="relative w-64 h-64 flex items-center justify-center">
              <div className="absolute inset-0 bg-gradient-to-br from-[#8b5cf6]/20 to-[#a855f7]/20 rounded-3xl blur-2xl" />
              <Mail className="w-32 h-32 text-[#8b5cf6] relative z-10" />

              {/* Scanning lines effect */}
              <motion.div
                style={{
                  y: useTransform(scanProgress, [0, 100], [-150, 150]),
                }}
                className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-[#a855f7] to-transparent"
              />

              {/* Data streams */}
              {[...Array(8)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0 }}
                  whileInView={{ opacity: [0, 1, 0], scale: [0, 1, 1.5] }}
                  transition={{
                    duration: 2,
                    delay: i * 0.2,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatDelay: 1,
                  }}
                  viewport={{ once: false }}
                  className="absolute w-2 h-2 bg-[#a855f7] rounded-full"
                  style={{
                    left: `${50 + Math.cos((i * Math.PI) / 4) * 40}%`,
                    top: `${50 + Math.sin((i * Math.PI) / 4) * 40}%`,
                  }}
                />
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

function CTASection() {
  return (
    <section className="py-40 px-4 bg-gradient-to-b from-white to-[#fafaf9]">
      <div className="max-w-4xl mx-auto text-center">
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-[clamp(2.5rem,8vw,5rem)] font-bold mb-8 leading-tight"
        >
          Ready to
          <br />
          <span className="text-[#71717a]">Reclaim Your Focus?</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="text-xl md:text-2xl text-[#52525b] mb-12 text-pretty"
        >
          Join thousands who've silenced the noise
        </motion.p>

        <motion.button
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="group relative px-12 py-6 bg-gradient-to-br from-[#8b5cf6] to-[#a855f7] text-white text-xl font-semibold rounded-2xl shadow-2xl overflow-hidden"
        >
          <span className="relative z-10 flex items-center gap-3">
            Start Free Trial
            <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
          </span>
          <div className="absolute inset-0 bg-gradient-to-br from-[#a855f7] to-[#8b5cf6] opacity-0 group-hover:opacity-100 transition-opacity" />
        </motion.button>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-8 text-[#71717a]"
        >
          No credit card required • 14-day trial • Cancel anytime
        </motion.p>
      </div>
    </section>
  )
}
